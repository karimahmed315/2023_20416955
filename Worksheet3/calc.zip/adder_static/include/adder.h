//The next two lines prevent including adder.h more than once in any .cpp file
#ifndef MATHSLIB_ADDER_H
	#define MATHSLIB_ADDER_H
	//function prototype
	int add (int a, int b );
#endif